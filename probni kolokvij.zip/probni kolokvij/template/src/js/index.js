import $ from "jquery";

//1.9) iz v3 todo.pdf dio s fetchBio
const get_todos = (callb) => {
    $.get("/api/todos", (res) => {
        callb(res);
    });
}

//iz v3  client js pa script-index.js

//privremena funkcija koja ce ispisat podatke u konzolu, da se vidi da li je sve ok

/*na kraju ovo makni, visak je i samo provjera
const ispisi = (podaci) => {
    console.log(podaci);  
};

//pokrece se kad se ucita stranica, i onda se poziva get_todos, a u get_todos se poziva ispisi
$(() => {
    get_todos(ispis); 
});
*/

/*
ako si dobro na stranici otvori F12 console i treba pisati:
(9) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
*/

//nakon promjena konzola treba biti prazna


//zad3: v3 todo.pdf ima tocno kako se radi create_todo
const createTodo = (todo) => {
    //3.7) pretvorba datuma:
    const datum=new Date(todo.timestamp).toLocaleDateString("en-US");

    //3.6)promjena ikone statusa
    const ikona =todo.done //todo.done je uvijet
        ? `<i class="bi bi-check-circle-fill text-success"></i>` //?-ako je true onda ovo
        : `<i class="bi bi-x-circle-fill text-danger"></i>`; //inače ovo

        //druga opcija pisanja ovog:
        /*
        let ikona;let ikona;
        if (todo.done) {
            ikona = "bi bi-check-circle-fill text-success";
        } else {
            ikona = "bi bi-x-circle-fill text-danger";
        }
        */
    const kartica = $(`
        <div class="col-12 col-sm-6 col-lg-4">
            <div class="card shadow rounded-5">
                <div class="card-body">
                    <h5 class="card-title">${todo.title}</h5>
                    <p class="mb-1">
                        <span class="fw-bold">When:</span> ${datum}
                    </p>
                    <p class="mb-1">
                        <span class="fw-bold">Status:</span>
                        ${ikona}
                    </p>
                    <div class="d-flex flex-column flex-md-row gap-4 mt-3">
                        <button class="btn btn-light border rounded-pill w-100 js-toggle" >Toggle</button> 
                        <button class="btn btn-light border rounded-pill w-100 js-remove">Remove</button>
                    </div>
                </div> 
                        
            </div>
        </div> 
    `);
    //3.5) dodaj js-toggle u button da bi se moglo mijenjat status podataka na stranici
    
    /*3.5) pozovi remove i toggle funkcije u get_todos, da se moze brisat i mijenjat status podataka na stranici
    
    odakle .js-remove i .js-toggle?
    */
    kartica.find(".js-remove").on("click", () => {
        removeTodo(todo.id);
    });
    kartica.find(".js-toggle").on("click", () => {
        toggleTodo(todo.id, todo.done);
    });

    return kartica;
}

//3.1) renderTodos funkcija koja ce renderat sve podatke iz todos niza, tj. ispisat ih na stranicu
//za fadeIn:
let prvo_ucitavanje = true;

const render_todos = (todos) => {
    const todosList = $("#todos"); 
    todosList.empty();

    todos.forEach(todo => {
        const kartica = createTodo(todo); //1.imam karticu
        todosList.append(kartica); //2.ubacim je u listu
        //3.8) fade-in
        if (prvo_ucitavanje) {
            kartica.hide().fadeIn(800); //3.animiram baš tu karticu(prvo ju sakrijem, pa onda fadeIn)
        }
    });
    prvo_ucitavanje = false; //nakon prvog ucitavanja, fadeIn se vise nece izvrsavat
}

//3.2) pozovi renderTodos u get_todos, da se ispisu podaci na stranicu
$(() => {
    get_todos(render_todos);
});
//3.3 remove funkcija koja ce brisat podatke iz todos niza, tj. brisat ih sa stranice
const removeTodo = (id) => {
    $.ajax({
        method: "DELETE",
        url: `/api/todos/${id}`,
        success: () => {
            get_todos(render_todos);
        }
    });
}

//3.4) toggle funkcija koja ce mijenjat status podataka iz todos niza, tj. mijenjat ih na stranici
const toggleTodo = (id, trenutno) => {
    $.ajax({
        method: "PUT",
        url: `/api/todos/${id}`,
        //NE KUZIM????
        contentType: "application/json",
        data: JSON.stringify({ done: ! trenutno}), //pretpostavljamo da je status false, pa ga mijenjamo u true
        success: () => {
            get_todos(render_todos);
        }
    });
}

//3.8) fade-in
//u p3
//u node_modules/jquery/dist/jquery.js vidi jel opacity show




