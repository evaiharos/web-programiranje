import express from 'express'
//1.5) import crypto iz vjezbi, da bi se moglo generirat id
import crypto from "crypto";
//1.5) import todos iz vjezbi, da bi se moglo importat u server.js
import todos from "./todos.js"; 

const app = express()

app.use(express.json()); //ovo moras dodat da radi post i put, jer express ne zna sam parsirat json, pa moras reci da ga parsira
app.use(express.static("../client/"));
app.use(express.urlencoded({ extended: false }));

//1.6) otvori vite.config.js i ako ima proxy onda moras koristit api
//api ustvari govori da su to nekakvi podatci, a ne html stranice, pa se onda moze napravit proxy, da se ne bi moralo stalno pisat localhost:3000/api/hello nego samo /api/hello
app.get("/api/todos", (req, res) => {
    res.send(todos);    
});

//1.7) uređivanje postojećih podataka
app.put("/api/todos/:id" , (req, res) => {
    const { id } = req.params;
    const index = todos.findIndex(t => t.id === id);
    if (index === -1) {
        res.status(404).send({ error: "Not found" });
        return;
    }
    todos[index] = { ...todos[index], ...req.body, id};
    // Filter
    //var newTodos = todos.filter((todo) => todo.done == true);
    res.send(todos[index]);
});

//1.8) brisanje
app.delete("/api/todos/:id", (req, res) => {
    const { id } = req.params;
    const index = todos.findIndex(todo => todo.id === id);

    if (index === -1) {
        res.status(404).send({ error: "Not found" });
        return;
    }

    const [deletedTodo] = todos.splice(index, 1);
    res.send({ message: "Todo deleted", todo: deletedTodo });
});



app.get("/hello", (req, res) => {
    res.send({ message: "Hello World" });    
});

app.get("/api/hello", (req, res) => {
    res.send({ message: "Hello World 2" });    
});

app.listen(3000, () => {
  console.log('Server is running on http://localhost:3000')
})
