//1.4) dodaj import, iz vjezbi kopirano ovo id, mora imat export default, da bi se moglo importat u server.js
import crypto from "crypto";

const todos = [
  { id: crypto.randomUUID(), title: "Buy groceries",     timestamp: 1764845228329, done: true },
  { id: crypto.randomUUID(), title: "Email client",      timestamp: 1764845228329, done: true  },
  { id: crypto.randomUUID(), title: "Clean desk",        timestamp: 1764931675258, done: false },
  { id: crypto.randomUUID(), title: "Pay bills",         timestamp: 1765104490843, done: false },
  { id: crypto.randomUUID(), title: "Read 20 pages",     timestamp: 1765018057945, done: false  },
  { id: crypto.randomUUID(), title: "Workout",           timestamp: 1765104490843, done: true },
  { id: crypto.randomUUID(), title: "Plan weekly tasks", timestamp: 1764845228329, done: true },
  { id: crypto.randomUUID(), title: "Water plants",      timestamp: 1765018057945, done: false  },
  { id: crypto.randomUUID(), title: "Review code",       timestamp: 1764931675258, done: false }
];

//1.4) potrebno da index.js moze ucitati
export default todos;

//1.4) provjera: u terminal:
/*
node --input-type=module -e 'const t = (await import("./todos.js")).default; console.log("zapisa:", t.length); console.log("kljucevi:", Object.keys(t[0])); console.log("id-evi razliciti:", new Set(t.map(x=>x.id)).size === t.length); console.log("prvi id:", t[0].id);'
ispis ako je sve ok:
zapisa: 9
kljucevi: [ 'id', 'title', 'timestamp', 'done' ]
id-evi razliciti: true
prvi id: 5f1c...-...-4...-...-..........
*/
