//1.1)za importanje jqueri, prije ovog npm install jquery na templateu
import $ from "jquery";
import { Modal } from "bootstrap";


const prettyDate = (dateStr) => {
    const formatter = new Intl.DateTimeFormat("en-US", {
        dateStyle: "short",
        timeStyle: "short"
    });
    return formatter.format(new Date(dateStr));
}

//1.10) getTodos
const getTodos = (callb) => {
    $.get("/api/todos", (res) => {
        callb(res);
    });
}
//za render treba
//moras u uredi td dodat modify da bi ga find mogo nac
const createRow = (todo) => {
    const status=todo.completed
        ? '<i class="bi bi-check-circle-fill text-success"></i>'
        : '<i class="bi bi-x-circle-fill text-danger"></i>';
    const uredi='<i class="bi bi-pencil-square text-secondary"></i>';
    const red= $(`
        <tr>
            <td>${todo.description}</td>
            <td>${prettyDate(todo.date)}</td>
            <td class="text-center">${status}</td>
            <td class="text-center modify">${uredi}</td> 
        </tr>
        
    `);
    red.find(".modify").on("click", () => openEditModal(todo));
    return red;
}
//1.11) renderTablerows
const renderTableRows = (todos) => {
    const tbody = $("#todosTable"); 
    tbody.empty();
    todos.forEach(todo => {
        tbody.append(createRow(todo));
    });
}

//2.2) instanciranje modala
const myModal = new Modal(document.getElementById('exampleModal'));//exampleModal pise u id u html
//2.3) hide
const hide=() =>{
    myModal.hide();
}
window.hide = hide;
//koristis u html kod gumba close
let trenutni_edit=null;
const openEditModal = (todo) => {
    trenutni_edit=todo.id;
    $("#description").val(todo.description);
    $("#date").val(todo.date);
    $("#completed").prop("checked", todo.completed);

    myModal.show();

}

//2.zad submit
const submit = () => {
    const todo = {
        id: trenutni_edit,
        description: $("#description").val(),
        date: $("#date").val(),
        completed: $("#completed").prop("checked")
    };

    $.ajax({
        method: "PUT",
        url: "/api/todos",
        data: JSON.stringify(todo),
        contentType: "application/json",
        dataType: "json",
        success: () => {
            getTodos(renderTableRows);
            myModal.hide();
        }
    });
};

window.submit = submit;

$(() => {
    getTodos(renderTableRows);
});