//iz p3 kopiraj sa slajda Express.js
//moras jos dodat todos.js

// if "type": "module" in package.json
import express from "express";
import todos from "./todos.js";


const app = express();

//treba za put rutu 2.zad kraj
app.use(express.json())
app.use(express.urlencoded({ extended: false }))



//kopiraj sa sljedeceg slajda
app.use(express.static("../src/")); //zamijeni clijent sa src jer se kod tebe tako klijent zove
//ovo static je ta staticna mapa u kojoj se nalazi klijent(src)

//1.7) get ruta
app.get("/api/todos", (req, res) => {
    res.send(todos);
});

//2.kraj: put odnosno uredjivanje podataka
app.put("/api/todos" , (req, res) => {
    const todo = req.body; //uzima iz bodyja zato sto je objekt vec tamo u tablici
    const index = todos.findIndex(t => t.id === todo.id);
    if (index === -1) {
        res.status(404).send({ error: "Not found" });
        return;
    }
    todos[index] = todo;

    res.send({ message: "Modified", todo });
});

//1.5) posluzitelj se otvara na portu 3000
app.listen(3000, () => {
console.log("Listening on port 3000");
});
