//iz p3 kopiraj sa slajda Express.js
//moras jos dodat todos.js

// if "type": "module" in package.json
import express from "express";
import todos from "./todos.js";

const app = express();

//kopiraj sa sljedeceg slajda
app.use(express.static("../src/")); //zamijeni clijent sa src jer se kod tebe tako klijent zove
//ovo static je ta staticna mapa u kojoj se nalazi klijent(src)

//1.7) get ruta
app.get("/api/todos", (req, res) => {
    res.send(todos);
});
//1.5) posluzitelj se otvara na portu 3000
app.listen(3000, () => {
console.log("Listening on port 3000");
});
