import { resolve } from "path";

export default {
    root: resolve(__dirname, "src"),
    build: {
        outDir: "../dist"
    },
    server: {
        port: 8080,
        //ovo moras dodat da radi 
        proxy: {
            "/api": "htttp://localhost:3000"
        }
    }
}