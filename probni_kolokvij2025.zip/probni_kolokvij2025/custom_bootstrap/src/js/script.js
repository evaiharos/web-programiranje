//1.1)za importanje jqueri, prije ovog npm install jquery na templateu
import $ from "jquery";

