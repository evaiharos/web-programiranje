// =====================================================================
// Zadatak 1: "lažni" podaci sa servera
// ---------------------------------------------------------------------
// Ovdje su SVE datoteke iz SVIH prikaza (Files, Shared, Pinned, Trash)
// iz prve zadaće, svaka kao jedan JavaScript objekt u polju `data`.
//
// Svaki objekt ima samo dva svojstva:
//   name       -> ime datoteke zajedno s ekstenzijom, npr. "audio.mp3"
//   categories -> polje kategorija kojima datoteka pripada:
//                 "shared", "pinned" ili "trash".
//                 Datoteka može imati 0 ili više kategorija, a ako ima
//                 "trash", onda nema nijednu drugu.
//
// Ikonu NE spremamo: render_data.js je zaključi iz ekstenzije imena.
//
// Varijabla je deklarirana s `const` na najvišoj razini skripte pa je
// vidljiva i u render_data.js, koja se u HTML-u učitava NAKON ove
// datoteke (redoslijed <script> oznaka je bitan!).
//
// Redoslijed objekata u polju određuje i "Default" poredak prikaza.
// =====================================================================

const data = [
    // --- datoteke koje se vide na "Files" (sve osim onih u smeću) ---
    { name: "audio.mp3",           categories: [] },                    // samo Files
    { name: "some_photo.png",      categories: ["pinned"] },            // Files + Pinned
    { name: "seminar_report.docx", categories: ["shared"] },            // Files + Shared
    { name: "manual.pdf",          categories: ["shared", "pinned"] },  // Files + Shared + Pinned
    { name: "rezultati.xlsx",      categories: ["pinned"] },            // Files + Pinned

    // --- datoteke u smeću: vide se SAMO na "Trash" ---
    { name: "photo2.png",          categories: ["trash"] },
    { name: "norway.mp4",          categories: ["trash"] },
    { name: "yet_another.jpg",     categories: ["trash"] },
    { name: "speech.wav",          categories: ["trash"] },
];
