// =====================================================================
// Zadatak 2 i 3: dinamičko renderiranje i sortiranje datoteka (jQuery)
// ---------------------------------------------------------------------
// Ovo je JEDINSTVENA skripta za sve četiri stranice. Kako zna koje
// datoteke treba prikazati? Svaka stranica u HTML-u na spremniku za
// kartice ima atribut data-category:
//
//   index.html  -> <section id="files" data-category="files">
//   shared.html -> <section id="files" data-category="shared">
//   pinned.html -> <section id="files" data-category="pinned">
//   trash.html  -> <section id="files" data-category="trash">
//
// Skripta pročita taj atribut i prema njemu filtrira polje `data`
// (iz fake_server_data.js). U HTML-u NIJE hard-kodirana nijedna datoteka:
// sve kartice nastaju ovdje, pa kod radi za BILO KOJE polje objekata
// oblika { name: "...", categories: [...] }.
// =====================================================================


// ---------------------------------------------------------------------
// Pomoćna tablica: ekstenzija datoteke -> emoji ikona.
// Zato ikonu ne moramo spremati u podatke (Zadatak 1): zaključimo je
// iz ekstenzije. Lako je dodati nove tipove datoteka.
// ---------------------------------------------------------------------
const ICONS = {
    mp3: "🎵", wav: "🎵",                 // zvuk
    png: "📷", jpg: "📷", jpeg: "📷",     // slike
    mp4: "🎥",                            // video
    docx: "📘",                           // Word dokument
    pdf: "📕",                            // PDF
    xlsx: "📊",                           // Excel tablica
};
const DEFAULT_ICON = "📄";               // za nepoznatu ekstenziju

// Trajanje animacije (u milisekundama) za fadeOut/fadeIn
const ANIMATION_MS = 400;


// ---------------------------------------------------------------------
// Vraća emoji ikonu za zadano ime datoteke.
// "manual.pdf" -> split(".") -> ["manual", "pdf"] -> pop() -> "pdf"
// toLowerCase() da bi i "SLIKA.PNG" dobila ikonu slike.
// ---------------------------------------------------------------------
function getIcon(fileName) {
    const extension = fileName.split(".").pop().toLowerCase();
    return ICONS[extension] || DEFAULT_ICON;   // || => zamjenska vrijednost
}


// ---------------------------------------------------------------------
// Filtriranje: koje datoteke pripadaju trenutnoj stranici?
//   - "files": sve datoteke OSIM onih s kategorijom "trash"
//   - ostale stranice: samo datoteke koje imaju tu kategoriju
// Array.filter() vraća NOVO polje s elementima za koje funkcija vrati true,
// a includes() provjerava sadrži li polje zadanu vrijednost.
// ---------------------------------------------------------------------
function filterFiles(files, category) {
    if (category === "files") {
        return files.filter(file => !file.categories.includes("trash"));
    }
    return files.filter(file => file.categories.includes(category));
}


// ---------------------------------------------------------------------
// Sortiranje prema vrijednosti iz izbornika <select id="sort">:
//   "default" -> izvorni redoslijed iz polja data
//   "name-asc" -> po imenu A-Z,   "name-desc" -> po imenu Z-A
// [...files] radi KOPIJU polja, jer sort() mijenja polje nad kojim se
// pozove - a izvorni poredak trebamo sačuvati za opciju "Default".
// localeCompare() uspoređuje dva stringa abecedno (vraća <0, 0 ili >0).
// ---------------------------------------------------------------------
function sortFiles(files, sortBy) {
    const copy = [...files];

    if (sortBy === "name-asc") {
        copy.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortBy === "name-desc") {
        copy.sort((a, b) => b.name.localeCompare(a.name));
    }

    return copy;   // za "default" vraćamo nepromijenjenu kopiju
}


// ---------------------------------------------------------------------
// Stvara jQuery element jedne kartice. Rezultat je isti HTML kao u
// prvoj zadaći:
//
// <article class="file">
//     <div class="file-icon">🎵</div>
//     <div class="file-footer">
//         <span class="file-name">audio.mp3</span>
//         <div class="file-actions"> ...3 Font Awesome ikone... </div>
//     </div>
// </article>
//
// $("<tag>", { ... }) stvara NOVI element sa zadanim atributima.
// Ime postavljamo s .text() (a ne .html()) - tako se eventualni HTML u
// imenu datoteke prikaže kao običan tekst i ne može "razbiti" stranicu.
// ---------------------------------------------------------------------
function createFileCard(file) {
    // Akcije: download, share, trash (Font Awesome ikone, klase fa-solid fa-...)
    const $actions = $("<div>", { class: "file-actions" }).append(
        $("<a>", { href: "#", title: "Download" }).append($("<i>", { class: "fa-solid fa-download" })),
        $("<a>", { href: "#", title: "Share" }).append($("<i>", { class: "fa-solid fa-share" })),
        $("<a>", { href: "#", title: "Delete" }).append($("<i>", { class: "fa-solid fa-trash" }))
    );

    // Donji red kartice: ime + akcije
    const $footer = $("<div>", { class: "file-footer" }).append(
        $("<span>", { class: "file-name" }).text(file.name),
        $actions
    );

    // Cijela kartica: velika ikona + donji red
    return $("<article>", { class: "file" }).append(
        $("<div>", { class: "file-icon" }).text(getIcon(file.name)),
        $footer
    );
}


// ---------------------------------------------------------------------
// Iscrtava zadane datoteke u spremnik: prvo ga isprazni (.empty()),
// a zatim doda (.append()) po jednu karticu za svaku datoteku.
// map() pretvara polje objekata u polje jQuery elemenata.
// ---------------------------------------------------------------------
function renderFiles($container, files) {
    $container.empty();
    $container.append(files.map(createFileCard));
}


// =====================================================================
// $(() => { ... }) je jQuery kratica za $(document).ready(...):
// kod se izvrši tek kad je cijeli HTML učitan, tj. kad elementi
// #files i #sort sigurno postoje (skripta je u <head>, PRIJE <body>!).
// =====================================================================
$(() => {
    const $files = $("#files");          // spremnik za kartice
    const $sort = $("#sort");            // izbornik za sortiranje

    // Ako stranica nema spremnik, nemamo što raditi
    if ($files.length === 0) {
        return;
    }

    // .data("category") čita HTML atribut data-category="..."
    const category = $files.data("category");

    // Datoteke koje pripadaju ovoj stranici (izvorni redoslijed)
    const pageFiles = filterFiles(data, category);

    // Prvo iscrtavanje (Zadatak 2) uz animaciju: spremnik sakrijemo,
    // napunimo karticama i zatim ga postupno prikažemo (fadeIn).
    $files.hide();
    renderFiles($files, sortFiles(pageFiles, $sort.val()));
    $files.fadeIn(ANIMATION_MS);

    // -----------------------------------------------------------------
    // Zadatak 3: sortiranje s animacijom.
    // Događaj "change" okida se kad korisnik odabere drugu opciju.
    // Animacija (kao u videu): stare kartice postupno nestanu (fadeOut),
    // u callback funkciji - koja se pozove TEK kad fadeOut završi -
    // iscrtamo sortirane kartice i zatim ih postupno prikažemo (fadeIn).
    // .stop(true, true) prekida animaciju koja je možda još u tijeku
    // (ako korisnik brzo mijenja opcije), da se animacije ne gomilaju.
    // -----------------------------------------------------------------
    $sort.on("change", function () {
        const sortBy = $(this).val();    // vrijednost odabrane <option>

        $files.stop(true, true).fadeOut(ANIMATION_MS, () => {
            renderFiles($files, sortFiles(pageFiles, sortBy));
            $files.fadeIn(ANIMATION_MS);
        });
    });
});
