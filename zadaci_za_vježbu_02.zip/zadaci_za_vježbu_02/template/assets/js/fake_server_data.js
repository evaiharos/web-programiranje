// Zadatak 1: sve datoteke iz svih prikaza (ime + kategorije)
// primjer objekta: { name: "audio.mp3", categories: ["pinned"] }
const data = [

];
