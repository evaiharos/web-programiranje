// Zadatak 2 i 3: dinamicko renderiranje i sortiranje (jQuery)

$(() => {

});
